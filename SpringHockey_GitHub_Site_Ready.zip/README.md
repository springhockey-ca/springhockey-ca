# SpringHockey.ca

GitHub Pages website for Spring Hockey in Canada.

## Files
- `index.html` — main website
- `images/` — five geography images

## GitHub Pages
Upload `index.html` and the `images` folder to the repository root.
Then enable GitHub Pages from Settings → Pages → Deploy from a branch → main → / (root).

The search box is intentionally not included yet. It can be added when teams, tournaments, camps, rinks and cities are uploaded.
